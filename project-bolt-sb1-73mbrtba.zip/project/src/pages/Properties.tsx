import React, { useState, useEffect } from 'react';
import {
  Container,
  Grid,
  Card,
  CardMedia,
  CardContent,
  Typography,
  Button,
  Box,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Chip,
  Pagination,
  CircularProgress,
  Alert
} from '@mui/material';
import { Search, MapPin, Bed, Bath, Square, DollarSign } from 'lucide-react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import moment from 'moment';

interface Property {
  _id: string;
  title: string;
  description: string;
  address: {
    street: string;
    city: string;
    state: string;
    zipCode: string;
  };
  propertyType: string;
  bedrooms: number;
  bathrooms: number;
  squareFootage?: number;
  rentPrice: number;
  images: Array<{ url: string; caption?: string; isPrimary?: boolean }>;
  amenities: string[];
  availability: {
    isAvailable: boolean;
    availableFrom: string;
  };
  owner: {
    name: string;
    email: string;
  };
  createdAt: string;
}

const Properties: React.FC = () => {
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [filters, setFilters] = useState({
    search: '',
    propertyType: '',
    minPrice: '',
    maxPrice: '',
    bedrooms: '',
    bathrooms: '',
    city: '',
    state: ''
  });

  const propertyTypes = [
    { value: 'apartment', label: 'Apartment' },
    { value: 'house', label: 'House' },
    { value: 'condo', label: 'Condo' },
    { value: 'townhouse', label: 'Townhouse' },
    { value: 'studio', label: 'Studio' },
    { value: 'other', label: 'Other' }
  ];

  const fetchProperties = async (page = 1) => {
    try {
      setLoading(true);
      const params = new URLSearchParams({
        page: page.toString(),
        limit: '12',
        ...Object.fromEntries(
          Object.entries(filters).filter(([_, value]) => value !== '')
        )
      });

      const response = await axios.get(`/properties?${params}`);
      
      if (response.data.success) {
        setProperties(response.data.properties);
        setTotalPages(response.data.pagination.totalPages);
        setCurrentPage(response.data.pagination.currentPage);
      }
    } catch (error: any) {
      setError('Failed to load properties. Please try again.');
      console.error('Properties fetch error:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProperties(1);
  }, [filters]);

  const handleFilterChange = (field: string, value: string) => {
    setFilters(prev => ({ ...prev, [field]: value }));
    setCurrentPage(1);
  };

  const handlePageChange = (_: React.ChangeEvent<unknown>, page: number) => {
    setCurrentPage(page);
    fetchProperties(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const clearFilters = () => {
    setFilters({
      search: '',
      propertyType: '',
      minPrice: '',
      maxPrice: '',
      bedrooms: '',
      bathrooms: '',
      city: '',
      state: ''
    });
  };

  const getImageUrl = (property: Property) => {
    const primaryImage = property.images.find(img => img.isPrimary);
    if (primaryImage?.url) return primaryImage.url;
    
    if (property.images.length > 0) return property.images[0].url;
    
    // Default placeholder based on property type
    const placeholders = {
      apartment: 'https://images.pexels.com/photos/271816/pexels-photo-271816.jpeg?auto=compress&cs=tinysrgb&w=400',
      house: 'https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=400',
      condo: 'https://images.pexels.com/photos/280229/pexels-photo-280229.jpeg?auto=compress&cs=tinysrgb&w=400',
      townhouse: 'https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg?auto=compress&cs=tinysrgb&w=400',
      studio: 'https://images.pexels.com/photos/271743/pexels-photo-271743.jpeg?auto=compress&cs=tinysrgb&w=400'
    };
    
    return placeholders[property.propertyType as keyof typeof placeholders] || placeholders.apartment;
  };

  if (error) {
    return (
      <Container maxWidth="lg" sx={{ py: 4 }}>
        <Alert severity="error" sx={{ borderRadius: 2 }}>
          {error}
        </Alert>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      {/* Header */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h3" fontWeight={700} gutterBottom>
          Find Your Perfect Rental
        </Typography>
        <Typography variant="h6" color="text.secondary">
          Discover thousands of verified rental properties
        </Typography>
      </Box>

      {/* Search and Filters */}
      <Card sx={{ p: 3, mb: 4, boxShadow: '0 4px 20px rgba(0,0,0,0.08)' }}>
        <Grid container spacing={3}>
          {/* Search */}
          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              placeholder="Search by location, title..."
              value={filters.search}
              onChange={(e) => handleFilterChange('search', e.target.value)}
              InputProps={{
                startAdornment: (
                  <Box sx={{ mr: 1, color: 'text.secondary' }}>
                    <Search size={20} />
                  </Box>
                )
              }}
            />
          </Grid>

          {/* Property Type */}
          <Grid item xs={12} sm={6} md={2}>
            <FormControl fullWidth>
              <InputLabel>Type</InputLabel>
              <Select
                value={filters.propertyType}
                label="Type"
                onChange={(e) => handleFilterChange('propertyType', e.target.value)}
              >
                <MenuItem value="">All Types</MenuItem>
                {propertyTypes.map(type => (
                  <MenuItem key={type.value} value={type.value}>
                    {type.label}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>

          {/* Bedrooms */}
          <Grid item xs={12} sm={6} md={2}>
            <FormControl fullWidth>
              <InputLabel>Bedrooms</InputLabel>
              <Select
                value={filters.bedrooms}
                label="Bedrooms"
                onChange={(e) => handleFilterChange('bedrooms', e.target.value)}
              >
                <MenuItem value="">Any</MenuItem>
                {[0, 1, 2, 3, 4, 5].map(num => (
                  <MenuItem key={num} value={num.toString()}>
                    {num === 0 ? 'Studio' : `${num}+ BR`}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>

          {/* Price Range */}
          <Grid item xs={12} sm={6} md={2}>
            <TextField
              fullWidth
              type="number"
              label="Min Price"
              value={filters.minPrice}
              onChange={(e) => handleFilterChange('minPrice', e.target.value)}
            />
          </Grid>

          <Grid item xs={12} sm={6} md={2}>
            <TextField
              fullWidth
              type="number"
              label="Max Price"
              value={filters.maxPrice}
              onChange={(e) => handleFilterChange('maxPrice', e.target.value)}
            />
          </Grid>

          {/* Clear Filters Button */}
          <Grid item xs={12} sx={{ display: 'flex', justifyContent: 'flex-end' }}>
            <Button
              onClick={clearFilters}
              variant="outlined"
              sx={{ borderRadius: 2 }}
            >
              Clear Filters
            </Button>
          </Grid>
        </Grid>
      </Card>

      {/* Loading State */}
      {loading && (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
          <CircularProgress size={40} />
        </Box>
      )}

      {/* Properties Grid */}
      {!loading && (
        <>
          <Grid container spacing={3}>
            {properties.map((property) => (
              <Grid item xs={12} sm={6} md={4} key={property._id}>
                <Card
                  sx={{
                    height: '100%',
                    display: 'flex',
                    flexDirection: 'column',
                    transition: 'all 0.3s ease',
                    '&:hover': {
                      transform: 'translateY(-4px)',
                      boxShadow: '0 8px 30px rgba(0,0,0,0.12)'
                    }
                  }}
                >
                  <CardMedia
                    component="img"
                    height="240"
                    image={getImageUrl(property)}
                    alt={property.title}
                    sx={{ objectFit: 'cover' }}
                  />
                  
                  <CardContent sx={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
                    {/* Property Type Chip */}
                    <Box sx={{ mb: 1 }}>
                      <Chip
                        label={propertyTypes.find(t => t.value === property.propertyType)?.label || property.propertyType}
                        size="small"
                        sx={{ bgcolor: 'primary.light', color: 'white' }}
                      />
                    </Box>

                    {/* Title */}
                    <Typography variant="h6" fontWeight={600} gutterBottom>
                      {property.title}
                    </Typography>

                    {/* Address */}
                    <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                      <MapPin size={16} color="#666" />
                      <Typography variant="body2" color="text.secondary" sx={{ ml: 0.5 }}>
                        {property.address.city}, {property.address.state}
                      </Typography>
                    </Box>

                    {/* Property Details */}
                    <Box sx={{ display: 'flex', gap: 2, mb: 2, flexWrap: 'wrap' }}>
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <Bed size={16} color="#666" />
                        <Typography variant="body2" sx={{ ml: 0.5 }}>
                          {property.bedrooms} BR
                        </Typography>
                      </Box>
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <Bath size={16} color="#666" />
                        <Typography variant="body2" sx={{ ml: 0.5 }}>
                          {property.bathrooms} BA
                        </Typography>
                      </Box>
                      {property.squareFootage && (
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                          <Square size={16} color="#666" />
                          <Typography variant="body2" sx={{ ml: 0.5 }}>
                            {property.squareFootage.toLocaleString()} sq ft
                          </Typography>
                        </Box>
                      )}
                    </Box>

                    {/* Price */}
                    <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                      <DollarSign size={20} color="#1976d2" />
                      <Typography variant="h6" fontWeight={700} color="primary.main">
                        ${property.rentPrice.toLocaleString()}/month
                      </Typography>
                    </Box>

                    {/* Available From */}
                    <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                      Available from {moment(property.availability.availableFrom).format('MMM DD, YYYY')}
                    </Typography>

                    {/* Amenities Preview */}
                    {property.amenities.length > 0 && (
                      <Box sx={{ mb: 2 }}>
                        <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
                          {property.amenities.slice(0, 3).map((amenity, index) => (
                            <Chip
                              key={index}
                              label={amenity}
                              size="small"
                              variant="outlined"
                            />
                          ))}
                          {property.amenities.length > 3 && (
                            <Chip
                              label={`+${property.amenities.length - 3} more`}
                              size="small"
                              variant="outlined"
                            />
                          )}
                        </Box>
                      </Box>
                    )}

                    {/* Action Button */}
                    <Box sx={{ mt: 'auto' }}>
                      <Button
                        component={Link}
                        to={`/properties/${property._id}`}
                        variant="contained"
                        fullWidth
                        sx={{ borderRadius: 2 }}
                      >
                        View Details
                      </Button>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>

          {/* No Results */}
          {properties.length === 0 && !loading && (
            <Box sx={{ textAlign: 'center', py: 8 }}>
              <Typography variant="h6" color="text.secondary" gutterBottom>
                No properties found
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Try adjusting your search filters to find more results.
              </Typography>
            </Box>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
              <Pagination
                count={totalPages}
                page={currentPage}
                onChange={handlePageChange}
                color="primary"
                size="large"
              />
            </Box>
          )}
        </>
      )}
    </Container>
  );
};

export default Properties;