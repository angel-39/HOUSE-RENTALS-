import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Container,
  Grid,
  Card,
  CardContent,
  Typography,
  Button,
  Box,
  Chip,
  Avatar,
  Divider,
  Alert,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField
} from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterMoment } from '@mui/x-date-pickers/AdapterMoment';
import {
  MapPin,
  Bed,
  Bath,
  Square,
  DollarSign,
  Calendar,
  User,
  Mail,
  Phone,
  ArrowLeft,
  CheckCircle,
  X
} from 'lucide-react';
import { Carousel } from 'antd';
import axios from 'axios';
import moment from 'moment';
import { useAuth } from '../contexts/AuthContext';

interface Property {
  _id: string;
  title: string;
  description: string;
  address: {
    street: string;
    city: string;
    state: string;
    zipCode: string;
  };
  propertyType: string;
  bedrooms: number;
  bathrooms: number;
  squareFootage?: number;
  rentPrice: number;
  securityDeposit: number;
  amenities: string[];
  images: Array<{ url: string; caption?: string; isPrimary?: boolean }>;
  availability: {
    isAvailable: boolean;
    availableFrom: string;
    leaseTerm: string;
  };
  utilities: {
    included: string[];
    cost: number;
  };
  policies: {
    petsAllowed: boolean;
    smokingAllowed: boolean;
    petDeposit: number;
  };
  owner: {
    _id: string;
    name: string;
    email: string;
    phone?: string;
  };
  createdAt: string;
}

const PropertyDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [property, setProperty] = useState<Property | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [bookingDialogOpen, setBookingDialogOpen] = useState(false);
  const [bookingData, setBookingData] = useState({
    startDate: null as moment.Moment | null,
    endDate: null as moment.Moment | null,
    specialRequests: ''
  });
  const [submittingBooking, setSubmittingBooking] = useState(false);

  useEffect(() => {
    if (id) {
      fetchProperty();
    }
  }, [id]);

  const fetchProperty = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`/properties/${id}`);
      
      if (response.data.success) {
        setProperty(response.data.property);
      } else {
        setError('Property not found');
      }
    } catch (error: any) {
      setError('Failed to load property details');
      console.error('Property fetch error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleBookingSubmit = async () => {
    if (!user) {
      navigate('/login');
      return;
    }

    if (!bookingData.startDate || !bookingData.endDate) {
      setError('Please select both start and end dates');
      return;
    }

    if (bookingData.startDate.isSameOrAfter(bookingData.endDate)) {
      setError('End date must be after start date');
      return;
    }

    try {
      setSubmittingBooking(true);
      const response = await axios.post('/bookings', {
        propertyId: property?._id,
        startDate: bookingData.startDate.toISOString(),
        endDate: bookingData.endDate.toISOString(),
        specialRequests: bookingData.specialRequests
      });

      if (response.data.success) {
        setBookingDialogOpen(false);
        navigate('/dashboard/bookings');
      }
    } catch (error: any) {
      setError(error.response?.data?.message || 'Failed to submit booking request');
    } finally {
      setSubmittingBooking(false);
    }
  };

  const getImageUrls = (property: Property) => {
    if (property.images.length > 0) {
      return property.images.map(img => img.url);
    }
    
    // Default placeholder based on property type
    const placeholders = {
      apartment: [
        'https://images.pexels.com/photos/271816/pexels-photo-271816.jpeg?auto=compress&cs=tinysrgb&w=800',
        'https://images.pexels.com/photos/439391/pexels-photo-439391.jpeg?auto=compress&cs=tinysrgb&w=800',
        'https://images.pexels.com/photos/271743/pexels-photo-271743.jpeg?auto=compress&cs=tinysrgb&w=800'
      ],
      house: [
        'https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=800',
        'https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg?auto=compress&cs=tinysrgb&w=800',
        'https://images.pexels.com/photos/280229/pexels-photo-280229.jpeg?auto=compress&cs=tinysrgb&w=800'
      ]
    };
    
    return placeholders[property.propertyType as keyof typeof placeholders] || placeholders.apartment;
  };

  if (loading) {
    return (
      <Container maxWidth="lg" sx={{ py: 4 }}>
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
          <CircularProgress size={40} />
        </Box>
      </Container>
    );
  }

  if (error || !property) {
    return (
      <Container maxWidth="lg" sx={{ py: 4 }}>
        <Alert severity="error" sx={{ borderRadius: 2 }}>
          {error || 'Property not found'}
        </Alert>
      </Container>
    );
  }

  const imageUrls = getImageUrls(property);
  const isOwner = user?.id === property.owner._id;
  const canBook = user?.role === 'renter' && !isOwner && property.availability.isAvailable;

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      {/* Back Button */}
      <Button
        startIcon={<ArrowLeft size={20} />}
        onClick={() => navigate('/properties')}
        sx={{ mb: 3, borderRadius: 2 }}
      >
        Back to Properties
      </Button>

      <Grid container spacing={4}>
        {/* Main Content */}
        <Grid item xs={12} md={8}>
          {/* Image Carousel */}
          <Card sx={{ mb: 3, overflow: 'hidden' }}>
            <Carousel autoplay autoplaySpeed={5000} dots>
              {imageUrls.map((url, index) => (
                <div key={index}>
                  <Box
                    component="img"
                    src={url}
                    alt={`${property.title} - Image ${index + 1}`}
                    sx={{
                      width: '100%',
                      height: 400,
                      objectFit: 'cover'
                    }}
                  />
                </div>
              ))}
            </Carousel>
          </Card>

          {/* Property Details */}
          <Card sx={{ p: 3 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
              <Box>
                <Chip
                  label={property.propertyType.charAt(0).toUpperCase() + property.propertyType.slice(1)}
                  sx={{ bgcolor: 'primary.light', color: 'white', mb: 2 }}
                />
                <Typography variant="h4" fontWeight={700} gutterBottom>
                  {property.title}
                </Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <MapPin size={20} color="#666" />
                  <Typography variant="h6" color="text.secondary" sx={{ ml: 1 }}>
                    {property.address.street}, {property.address.city}, {property.address.state} {property.address.zipCode}
                  </Typography>
                </Box>
              </Box>
              
              {property.availability.isAvailable && (
                <Chip
                  icon={<CheckCircle size={16} />}
                  label="Available"
                  color="success"
                  variant="outlined"
                />
              )}
            </Box>

            {/* Property Stats */}
            <Grid container spacing={3} sx={{ mb: 3 }}>
              <Grid item xs={6} sm={3}>
                <Box sx={{ textAlign: 'center', p: 2, bgcolor: 'grey.50', borderRadius: 2 }}>
                  <Bed size={24} color="#1976d2" />
                  <Typography variant="h6" fontWeight={600}>
                    {property.bedrooms}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Bedrooms
                  </Typography>
                </Box>
              </Grid>
              <Grid item xs={6} sm={3}>
                <Box sx={{ textAlign: 'center', p: 2, bgcolor: 'grey.50', borderRadius: 2 }}>
                  <Bath size={24} color="#1976d2" />
                  <Typography variant="h6" fontWeight={600}>
                    {property.bathrooms}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Bathrooms
                  </Typography>
                </Box>
              </Grid>
              {property.squareFootage && (
                <Grid item xs={6} sm={3}>
                  <Box sx={{ textAlign: 'center', p: 2, bgcolor: 'grey.50', borderRadius: 2 }}>
                    <Square size={24} color="#1976d2" />
                    <Typography variant="h6" fontWeight={600}>
                      {property.squareFootage.toLocaleString()}
                    </Typography>
                    <Typography variant="body2"  color="text.secondary">
                      Sq Ft
                    </Typography>
                  </Box>
                </Grid>
              )}
              <Grid item xs={6} sm={3}>
                <Box sx={{ textAlign: 'center', p: 2, bgcolor: 'grey.50', borderRadius: 2 }}>
                  <Calendar size={24} color="#1976d2" />
                  <Typography variant="h6" fontWeight={600}>
                    {property.availability.leaseTerm}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Lease Term
                  </Typography>
                </Box>
              </Grid>
            </Grid>

            <Divider sx={{ my: 3 }} />

            {/* Description */}
            <Typography variant="h6" fontWeight={600} gutterBottom>
              Description
            </Typography>
            <Typography variant="body1" sx={{ mb: 3, lineHeight: 1.7 }}>
              {property.description}
            </Typography>

            {/* Amenities */}
            {property.amenities.length > 0 && (
              <>
                <Typography variant="h6" fontWeight={600} gutterBottom>
                  Amenities
                </Typography>
                <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mb: 3 }}>
                  {property.amenities.map((amenity, index) => (
                    <Chip
                      key={index}
                      label={amenity}
                      variant="outlined"
                      sx={{ borderRadius: 2 }}
                    />
                  ))}
                </Box>
              </>
            )}

            {/* Utilities */}
            {property.utilities.included.length > 0 && (
              <>
                <Typography variant="h6" fontWeight={600} gutterBottom>
                  Utilities Included
                </Typography>
                <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mb: 3 }}>
                  {property.utilities.included.map((utility, index) => (
                    <Chip
                      key={index}
                      label={utility.charAt(0).toUpperCase() + utility.slice(1)}
                      color="primary"
                      variant="outlined"
                      sx={{ borderRadius: 2 }}
                    />
                  ))}
                </Box>
              </>
            )}

            {/* Policies */}
            <Typography variant="h6" fontWeight={600} gutterBottom>
              Property Policies
            </Typography>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={4}>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  {property.policies.petsAllowed ? (
                    <CheckCircle size={20} color="#4caf50" />
                  ) : (
                    <X size={20} color="#f44336" />
                  )}
                  <Typography sx={{ ml: 1 }}>
                    Pets {property.policies.petsAllowed ? 'Allowed' : 'Not Allowed'}
                  </Typography>
                </Box>
              </Grid>
              <Grid item xs={12} sm={4}>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  {property.policies.smokingAllowed ? (
                    <CheckCircle size={20} color="#4caf50" />
                  ) : (
                    <X size={20} color="#f44336" />
                  )}
                  <Typography sx={{ ml: 1 }}>
                    Smoking {property.policies.smokingAllowed ? 'Allowed' : 'Not Allowed'}
                  </Typography>
                </Box>
              </Grid>
              {property.policies.petsAllowed && property.policies.petDeposit > 0 && (
                <Grid item xs={12} sm={4}>
                  <Typography>
                    Pet Deposit: ${property.policies.petDeposit}
                  </Typography>
                </Grid>
              )}
            </Grid>
          </Card>
        </Grid>

        {/* Sidebar */}
        <Grid item xs={12} md={4}>
          {/* Pricing Card */}
          <Card sx={{ p: 3, mb: 3, position: 'sticky', top: 20 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
              <DollarSign size={24} color="#1976d2" />
              <Typography variant="h4" fontWeight={700} color="primary.main">
                ${property.rentPrice.toLocaleString()}
              </Typography>
              <Typography variant="h6" color="text.secondary" sx={{ ml: 1 }}>
                /month
              </Typography>
            </Box>

            <Box sx={{ mb: 3 }}>
              <Typography variant="body2" color="text.secondary">
                Security Deposit: ${property.securityDeposit.toLocaleString()}
              </Typography>
              {property.utilities.cost > 0 && (
                <Typography variant="body2" color="text.secondary">
                  Utilities: ${property.utilities.cost}/month
                </Typography>
              )}
              <Typography variant="body2" color="text.secondary">
                Available from: {moment(property.availability.availableFrom).format('MMM DD, YYYY')}
              </Typography>
            </Box>

            {canBook && (
              <Button
                variant="contained"
                fullWidth
                size="large"
                onClick={() => setBookingDialogOpen(true)}
                sx={{ mb: 2, borderRadius: 2 }}
              >
                Request Booking
              </Button>
            )}

            {!user && (
              <Button
                variant="contained"
                fullWidth
                size="large"
                onClick={() => navigate('/login')}
                sx={{ mb: 2, borderRadius: 2 }}
              >
                Login to Book
              </Button>
            )}

            {user?.role === 'owner' && !isOwner && (
              <Alert severity="info" sx={{ borderRadius: 2 }}>
                Switch to a renter account to book properties
              </Alert>
            )}
          </Card>

          {/* Owner Info Card */}
          <Card sx={{ p: 3 }}>
            <Typography variant="h6" fontWeight={600} gutterBottom>
              Property Owner
            </Typography>
            
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
              <Avatar sx={{ bgcolor: 'primary.main', mr: 2 }}>
                <User size={20} />
              </Avatar>
              <Box>
                <Typography variant="subtitle1" fontWeight={600}>
                  {property.owner.name}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Property Owner
                </Typography>
              </Box>
            </Box>

            <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
              <Mail size={16} color="#666" />
              <Typography variant="body2" sx={{ ml: 1 }}>
                {property.owner.email}
              </Typography>
            </Box>

            {property.owner.phone && (
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <Phone size={16} color="#666" />
                <Typography variant="body2" sx={{ ml: 1 }}>
                  {property.owner.phone}
                </Typography>
              </Box>
            )}

            <Button
              variant="outlined"
              fullWidth
              sx={{ borderRadius: 2 }}
              disabled={!user || user.role !== 'renter'}
            >
              Contact Owner
            </Button>
          </Card>
        </Grid>
      </Grid>

      {/* Booking Dialog */}
      <Dialog
        open={bookingDialogOpen}
        onClose={() => setBookingDialogOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Request Booking</DialogTitle>
        <DialogContent>
          <LocalizationProvider dateAdapter={AdapterMoment}>
            <Grid container spacing={3} sx={{ mt: 1 }}>
              <Grid item xs={12} sm={6}>
                <DatePicker
                  label="Move-in Date"
                  value={bookingData.startDate}
                  onChange={(date) => setBookingData(prev => ({ ...prev, startDate: date }))}
                  minDate={moment(property.availability.availableFrom)}
                  slotProps={{ textField: { fullWidth: true } }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <DatePicker
                  label="Move-out Date"
                  value={bookingData.endDate}
                  onChange={(date) => setBookingData(prev => ({ ...prev, endDate: date }))}
                  minDate={bookingData.startDate ? bookingData.startDate.clone().add(1, 'month') : moment().add(1, 'month')}
                  slotProps={{ textField: { fullWidth: true } }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  multiline
                  rows={3}
                  label="Special Requests (Optional)"
                  value={bookingData.specialRequests}
                  onChange={(e) => setBookingData(prev => ({ ...prev, specialRequests: e.target.value }))}
                  placeholder="Any special requests or questions for the owner..."
                />
              </Grid>
            </Grid>
          </LocalizationProvider>
        </DialogContent>
        <DialogActions sx={{ p: 3 }}>
          <Button
            onClick={() => setBookingDialogOpen(false)}
            disabled={submittingBooking}
          >
            Cancel
          </Button>
          <Button
            onClick={handleBookingSubmit}
            variant="contained"
            disabled={submittingBooking}
          >
            {submittingBooking ? <CircularProgress size={20} /> : 'Submit Request'}
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default PropertyDetail;