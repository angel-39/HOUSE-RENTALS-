import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Container, Grid, Paper, Typography, Box } from '@mui/material';
import { useAuth } from '../contexts/AuthContext';

// Import dashboard components (we'll create these)
import DashboardSidebar from '../components/dashboard/DashboardSidebar';
import DashboardOverview from '../components/dashboard/DashboardOverview';
import MyProperties from '../components/dashboard/MyProperties';
import MyBookings from '../components/dashboard/MyBookings';
import Profile from '../components/dashboard/Profile';

const Dashboard: React.FC = () => {
  const { user } = useAuth();

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return (
    <Box sx={{ bgcolor: 'grey.50', minHeight: '100vh' }}>
      <Container maxWidth="xl" sx={{ py: 4 }}>
        <Grid container spacing={3}>
          {/* Sidebar */}
          <Grid item xs={12} md={3}>
            <DashboardSidebar />
          </Grid>

          {/* Main Content */}
          <Grid item xs={12} md={9}>
            <Routes>
              <Route path="/" element={<DashboardOverview />} />
              <Route path="/properties" element={<MyProperties />} />
              <Route path="/bookings" element={<MyBookings />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="*" element={<Navigate to="/dashboard" replace />} />
            </Routes>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};

export default Dashboard;