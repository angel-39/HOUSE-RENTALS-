import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Button,
  Grid,
  Card,
  CardContent,
  CardMedia,
  Chip,
  IconButton,
  Menu,
  MenuItem,
  Alert,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  Fab
} from '@mui/material';
import { MoreVertical as MoreVert, Edit, Delete, Eye, MapPin, Bed, Bath, DollarSign, Plus, CheckCircle, XCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import moment from 'moment';

interface Property {
  _id: string;
  title: string;
  description: string;
  address: {
    street: string;
    city: string;
    state: string;
    zipCode: string;
  };
  propertyType: string;
  bedrooms: number;
  bathrooms: number;
  rentPrice: number;
  images: Array<{ url: string; isPrimary?: boolean }>;
  availability: {
    isAvailable: boolean;
    availableFrom: string;
  };
  createdAt: string;
}

const MyProperties: React.FC = () => {
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [menuAnchor, setMenuAnchor] = useState<null | HTMLElement>(null);
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [addPropertyDialogOpen, setAddPropertyDialogOpen] = useState(false);
  const [newProperty, setNewProperty] = useState({
    title: '',
    description: '',
    propertyType: 'apartment',
    bedrooms: 1,
    bathrooms: 1,
    rentPrice: '',
    securityDeposit: '',
    address: {
      street: '',
      city: '',
      state: '',
      zipCode: ''
    }
  });

  useEffect(() => {
    fetchProperties();
  }, []);

  const fetchProperties = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/properties/owner/my-properties');
      
      if (response.data.success) {
        setProperties(response.data.properties);
      }
    } catch (error: any) {
      setError('Failed to load properties');
      console.error('Properties fetch error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleMenuOpen = (event: React.MouseEvent<HTMLElement>, property: Property) => {
    setMenuAnchor(event.currentTarget);
    setSelectedProperty(property);
  };

  const handleMenuClose = () => {
    setMenuAnchor(null);
    setSelectedProperty(null);
  };

  const handleDeleteProperty = async () => {
    if (!selectedProperty) return;

    try {
      await axios.delete(`/properties/${selectedProperty._id}`);
      setProperties(prev => prev.filter(p => p._id !== selectedProperty._id));
      setDeleteDialogOpen(false);
      handleMenuClose();
    } catch (error: any) {
      setError('Failed to delete property');
    }
  };

  const handleAddProperty = async () => {
    try {
      const response = await axios.post('/properties', newProperty);
      
      if (response.data.success) {
        setProperties(prev => [response.data.property, ...prev]);
        setAddPropertyDialogOpen(false);
        setNewProperty({
          title: '',
          description: '',
          propertyType: 'apartment',
          bedrooms: 1,
          bathrooms: 1,
          rentPrice: '',
          securityDeposit: '',
          address: {
            street: '',
            city: '',
            state: '',
            zipCode: ''
          }
        });
      }
    } catch (error: any) {
      setError(error.response?.data?.message || 'Failed to add property');
    }
  };

  const getImageUrl = (property: Property) => {
    const primaryImage = property.images.find(img => img.isPrimary);
    if (primaryImage?.url) return primaryImage.url;
    
    if (property.images.length > 0) return property.images[0].url;
    
    return 'https://images.pexels.com/photos/271816/pexels-photo-271816.jpeg?auto=compress&cs=tinysrgb&w=400';
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
        <CircularProgress size={40} />
      </Box>
    );
  }

  return (
    <Box>
      {/* Header */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Box>
          <Typography variant="h4" fontWeight={700} gutterBottom>
            My Properties
          </Typography>
          <Typography variant="h6" color="text.secondary">
            Manage your rental properties
          </Typography>
        </Box>
        <Button
          variant="contained"
          startIcon={<Plus size={20} />}
          onClick={() => setAddPropertyDialogOpen(true)}
          sx={{ borderRadius: 2 }}
        >
          Add Property
        </Button>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 3, borderRadius: 2 }}>
          {error}
        </Alert>
      )}

      {/* Properties Grid */}
      {properties.length === 0 ? (
        <Card sx={{ p: 6, textAlign: 'center' }}>
          <Typography variant="h6" color="text.secondary" gutterBottom>
            No properties yet
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
            Start by adding your first rental property
          </Typography>
          <Button
            variant="contained"
            startIcon={<Plus size={20} />}
            onClick={() => setAddPropertyDialogOpen(true)}
          >
            Add Your First Property
          </Button>
        </Card>
      ) : (
        <Grid container spacing={3}>
          {properties.map((property) => (
            <Grid item xs={12} sm={6} md={4} key={property._id}>
              <Card
                sx={{
                  height: '100%',
                  display: 'flex',
                  flexDirection: 'column',
                  transition: 'all 0.3s ease',
                  '&:hover': {
                    transform: 'translateY(-4px)',
                    boxShadow: '0 8px 30px rgba(0,0,0,0.12)'
                  }
                }}
              >
                <CardMedia
                  component="img"
                  height="200"
                  image={getImageUrl(property)}
                  alt={property.title}
                />
                
                <CardContent sx={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
                  {/* Header with menu */}
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 1 }}>
                    <Chip
                      icon={property.availability.isAvailable ? <CheckCircle size={16} /> : <XCircle size={16} />}
                      label={property.availability.isAvailable ? 'Available' : 'Occupied'}
                      color={property.availability.isAvailable ? 'success' : 'default'}
                      size="small"
                    />
                    <IconButton
                      size="small"
                      onClick={(e) => handleMenuOpen(e, property)}
                    >
                      <MoreVert size={20} />
                    </IconButton>
                  </Box>

                  {/* Property Info */}
                  <Typography variant="h6" fontWeight={600} gutterBottom>
                    {property.title}
                  </Typography>

                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <MapPin size={16} color="#666" />
                    <Typography variant="body2" color="text.secondary" sx={{ ml: 0.5 }}>
                      {property.address.city}, {property.address.state}
                    </Typography>
                  </Box>

                  <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <Bed size={16} color="#666" />
                      <Typography variant="body2" sx={{ ml: 0.5 }}>
                        {property.bedrooms} BR
                      </Typography>
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <Bath size={16} color="#666" />
                      <Typography variant="body2" sx={{ ml: 0.5 }}>
                        {property.bathrooms} BA
                      </Typography>
                    </Box>
                  </Box>

                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <DollarSign size={20} color="#1976d2" />
                    <Typography variant="h6" fontWeight={700} color="primary.main">
                      ${property.rentPrice.toLocaleString()}/month
                    </Typography>
                  </Box>

                  <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                    Listed {moment(property.createdAt).fromNow()}
                  </Typography>

                  {/* Actions */}
                  <Box sx={{ mt: 'auto' }}>
                    <Button
                      component={Link}
                      to={`/properties/${property._id}`}
                      variant="outlined"
                      fullWidth
                      startIcon={<Eye size={16} />}
                      sx={{ borderRadius: 2 }}
                    >
                      View Details
                    </Button>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      )}

      {/* Property Menu */}
      <Menu
        anchorEl={menuAnchor}
        open={Boolean(menuAnchor)}
        onClose={handleMenuClose}
      >
        <MenuItem onClick={handleMenuClose}>
          <Edit size={16} style={{ marginRight: 8 }} />
          Edit Property
        </MenuItem>
        <MenuItem
          onClick={() => {
            setDeleteDialogOpen(true);
            handleMenuClose();
          }}
          sx={{ color: 'error.main' }}
        >
          <Delete size={16} style={{ marginRight: 8 }} />
          Delete Property
        </MenuItem>
      </Menu>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onClose={() => setDeleteDialogOpen(false)}>
        <DialogTitle>Delete Property</DialogTitle>
        <DialogContent>
          <Typography>
            Are you sure you want to delete "{selectedProperty?.title}"? This action cannot be undone.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleDeleteProperty} color="error" variant="contained">
            Delete
          </Button>
        </DialogActions>
      </Dialog>

      {/* Add Property Dialog */}
      <Dialog
        open={addPropertyDialogOpen}
        onClose={() => setAddPropertyDialogOpen(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>Add New Property</DialogTitle>
        <DialogContent>
          <Grid container spacing={3} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Property Title"
                value={newProperty.title}
                onChange={(e) => setNewProperty(prev => ({ ...prev, title: e.target.value }))}
                required
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                multiline
                rows={3}
                label="Description"
                value={newProperty.description}
                onChange={(e) => setNewProperty(prev => ({ ...prev, description: e.target.value }))}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth required>
                <InputLabel>Property Type</InputLabel>
                <Select
                  value={newProperty.propertyType}
                  label="Property Type"
                  onChange={(e) => setNewProperty(prev => ({ ...prev, propertyType: e.target.value }))}
                >
                  <MenuItem value="apartment">Apartment</MenuItem>
                  <MenuItem value="house">House</MenuItem>
                  <MenuItem value="condo">Condo</MenuItem>
                  <MenuItem value="townhouse">Townhouse</MenuItem>
                  <MenuItem value="studio">Studio</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                type="number"
                label="Bedrooms"
                value={newProperty.bedrooms}
                onChange={(e) => setNewProperty(prev => ({ ...prev, bedrooms: parseInt(e.target.value) }))}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                type="number"
                label="Bathrooms"
                value={newProperty.bathrooms}
                onChange={(e) => setNewProperty(prev => ({ ...prev, bathrooms: parseFloat(e.target.value) }))}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                type="number"
                label="Monthly Rent ($)"
                value={newProperty.rentPrice}
                onChange={(e) => setNewProperty(prev => ({ ...prev, rentPrice: e.target.value }))}
                required
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                type="number"
                label="Security Deposit ($)"
                value={newProperty.securityDeposit}
                onChange={(e) => setNewProperty(prev => ({ ...prev, securityDeposit: e.target.value }))}
                required
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Street Address"
                value={newProperty.address.street}
                onChange={(e) => setNewProperty(prev => ({
                  ...prev,
                  address: { ...prev.address, street: e.target.value }
                }))}
                required
              />
            </Grid>
            <Grid item xs={12} sm={4}>
              <TextField
                fullWidth
                label="City"
                value={newProperty.address.city}
                onChange={(e) => setNewProperty(prev => ({
                  ...prev,
                  address: { ...prev.address, city: e.target.value }
                }))}
                required
              />
            </Grid>
            <Grid item xs={12} sm={4}>
              <TextField
                fullWidth
                label="State"
                value={newProperty.address.state}
                onChange={(e) => setNewProperty(prev => ({
                  ...prev,
                  address: { ...prev.address, state: e.target.value }
                }))}
                required
              />
            </Grid>
            <Grid item xs={12} sm={4}>
              <TextField
                fullWidth
                label="ZIP Code"
                value={newProperty.address.zipCode}
                onChange={(e) => setNewProperty(prev => ({
                  ...prev,
                  address: { ...prev.address, zipCode: e.target.value }
                }))}
                required
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setAddPropertyDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleAddProperty} variant="contained">
            Add Property
          </Button>
        </DialogActions>
      </Dialog>

      {/* Floating Action Button */}
      <Fab
        color="primary"
        sx={{ position: 'fixed', bottom: 24, right: 24 }}
        onClick={() => setAddPropertyDialogOpen(true)}
      >
        <Plus size={24} />
      </Fab>
    </Box>
  );
};

export default MyProperties;