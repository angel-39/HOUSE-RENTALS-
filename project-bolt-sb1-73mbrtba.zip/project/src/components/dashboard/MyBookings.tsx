import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  Chip,
  Button,
  Alert,
  CircularProgress,
  Tabs,
  Tab,
  Avatar,
  Divider
} from '@mui/material';
import {
  Calendar,
  MapPin,
  DollarSign,
  User,
  CheckCircle,
  Clock,
  XCircle,
  MessageCircle
} from 'lucide-react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import moment from 'moment';
import { useAuth } from '../../contexts/AuthContext';

interface Booking {
  _id: string;
  property: {
    _id: string;
    title: string;
    address: {
      street: string;
      city: string;
      state: string;
    };
    rentPrice: number;
    images: Array<{ url: string; isPrimary?: boolean }>;
  };
  renter: {
    name: string;
    email: string;
    phone?: string;
  };
  owner: {
    name: string;
    email: string;
    phone?: string;
  };
  startDate: string;
  endDate: string;
  monthlyRent: number;
  securityDeposit: number;
  totalAmount: number;
  status: 'pending' | 'approved' | 'rejected' | 'active' | 'completed' | 'cancelled';
  paymentStatus: 'pending' | 'partial' | 'paid' | 'overdue';
  specialRequests?: string;
  createdAt: string;
}

const MyBookings: React.FC = () => {
  const { user } = useAuth();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState(0);

  useEffect(() => {
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/bookings');
      
      if (response.data.success) {
        setBookings(response.data.bookings);
      }
    } catch (error: any) {
      setError('Failed to load bookings');
      console.error('Bookings fetch error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusUpdate = async (bookingId: string, status: string) => {
    try {
      await axios.put(`/bookings/${bookingId}/status`, { status });
      setBookings(prev => prev.map(booking => 
        booking._id === bookingId ? { ...booking, status: status as any } : booking
      ));
    } catch (error: any) {
      setError('Failed to update booking status');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'warning';
      case 'approved': return 'info';
      case 'active': return 'success';
      case 'completed': return 'default';
      case 'rejected': return 'error';
      case 'cancelled': return 'error';
      default: return 'default';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return <Clock size={16} />;
      case 'approved': return <CheckCircle size={16} />;
      case 'active': return <CheckCircle size={16} />;
      case 'completed': return <CheckCircle size={16} />;
      case 'rejected': return <XCircle size={16} />;
      case 'cancelled': return <XCircle size={16} />;
      default: return <Clock size={16} />;
    }
  };

  const filterBookings = (status?: string) => {
    if (!status) return bookings;
    return bookings.filter(booking => booking.status === status);
  };

  const tabFilters = [
    { label: 'All', filter: undefined },
    { label: 'Pending', filter: 'pending' },
    { label: 'Active', filter: 'active' },
    { label: 'Completed', filter: 'completed' }
  ];

  const filteredBookings = filterBookings(tabFilters[activeTab].filter);

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
        <CircularProgress size={40} />
      </Box>
    );
  }

  return (
    <Box>
      {/* Header */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" fontWeight={700} gutterBottom>
          My Bookings
        </Typography>
        <Typography variant="h6" color="text.secondary">
          {user?.role === 'owner' ? 'Manage booking requests for your properties' : 'Track your rental applications and bookings'}
        </Typography>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 3, borderRadius: 2 }}>
          {error}
        </Alert>
      )}

      {/* Tabs */}
      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
        <Tabs value={activeTab} onChange={(_, newValue) => setActiveTab(newValue)}>
          {tabFilters.map((tab, index) => (
            <Tab
              key={index}
              label={`${tab.label} (${filterBookings(tab.filter).length})`}
            />
          ))}
        </Tabs>
      </Box>

      {/* Bookings List */}
      {filteredBookings.length === 0 ? (
        <Card sx={{ p: 6, textAlign: 'center' }}>
          <Typography variant="h6" color="text.secondary" gutterBottom>
            No bookings found
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
            {user?.role === 'owner' 
              ? 'No booking requests have been made for your properties yet.'
              : 'You haven\'t made any booking requests yet.'
            }
          </Typography>
          {user?.role === 'renter' && (
            <Button
              component={Link}
              to="/properties"
              variant="contained"
            >
              Browse Properties
            </Button>
          )}
        </Card>
      ) : (
        <Grid container spacing={3}>
          {filteredBookings.map((booking) => (
            <Grid item xs={12} key={booking._id}>
              <Card
                sx={{
                  transition: 'all 0.3s ease',
                  '&:hover': {
                    boxShadow: '0 8px 30px rgba(0,0,0,0.12)'
                  }
                }}
              >
                <CardContent sx={{ p: 3 }}>
                  <Grid container spacing={3}>
                    {/* Property Image */}
                    <Grid item xs={12} sm={3}>
                      <Box
                        component="img"
                        src={booking.property.images.find(img => img.isPrimary)?.url || 
                             booking.property.images[0]?.url || 
                             'https://images.pexels.com/photos/271816/pexels-photo-271816.jpeg?auto=compress&cs=tinysrgb&w=300'}
                        alt={booking.property.title}
                        sx={{
                          width: '100%',
                          height: 150,
                          objectFit: 'cover',
                          borderRadius: 2
                        }}
                      />
                    </Grid>

                    {/* Booking Details */}
                    <Grid item xs={12} sm={6}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                        <Chip
                          icon={getStatusIcon(booking.status)}
                          label={booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                          color={getStatusColor(booking.status) as any}
                          size="small"
                        />
                        <Chip
                          label={booking.paymentStatus.charAt(0).toUpperCase() + booking.paymentStatus.slice(1)}
                          variant="outlined"
                          size="small"
                        />
                      </Box>

                      <Typography variant="h6" fontWeight={600} gutterBottom>
                        {booking.property.title}
                      </Typography>

                      <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                        <MapPin size={16} color="#666" />
                        <Typography variant="body2" color="text.secondary" sx={{ ml: 0.5 }}>
                          {booking.property.address.city}, {booking.property.address.state}
                        </Typography>
                      </Box>

                      <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                        <Calendar size={16} color="#666" />
                        <Typography variant="body2" color="text.secondary" sx={{ ml: 0.5 }}>
                          {moment(booking.startDate).format('MMM DD, YYYY')} - {moment(booking.endDate).format('MMM DD, YYYY')}
                        </Typography>
                      </Box>

                      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                        <DollarSign size={16} color="#1976d2" />
                        <Typography variant="body2" sx={{ ml: 0.5 }}>
                          ${booking.monthlyRent.toLocaleString()}/month
                        </Typography>
                      </Box>

                      {/* Contact Info */}
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <Avatar sx={{ width: 32, height: 32, mr: 1, bgcolor: 'primary.main' }}>
                          <User size={16} />
                        </Avatar>
                        <Box>
                          <Typography variant="body2" fontWeight={600}>
                            {user?.role === 'owner' ? booking.renter.name : booking.owner.name}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            {user?.role === 'owner' ? 'Renter' : 'Property Owner'}
                          </Typography>
                        </Box>
                      </Box>
                    </Grid>

                    {/* Actions */}
                    <Grid item xs={12} sm={3}>
                      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1, height: '100%' }}>
                        <Typography variant="h6" fontWeight={700} color="primary.main">
                          ${booking.totalAmount.toLocaleString()}
                        </Typography>
                        <Typography variant="body2" color="text.secondary" gutterBottom>
                          Total Amount
                        </Typography>

                        <Divider sx={{ my: 1 }} />

                        {user?.role === 'owner' && booking.status === 'pending' && (
                          <>
                            <Button
                              variant="contained"
                              size="small"
                              onClick={() => handleStatusUpdate(booking._id, 'approved')}
                              sx={{ borderRadius: 2 }}
                            >
                              Approve
                            </Button>
                            <Button
                              variant="outlined"
                              size="small"
                              color="error"
                              onClick={() => handleStatusUpdate(booking._id, 'rejected')}
                              sx={{ borderRadius: 2 }}
                            >
                              Reject
                            </Button>
                          </>
                        )}

                        <Button
                          variant="outlined"
                          size="small"
                          startIcon={<MessageCircle size={16} />}
                          sx={{ borderRadius: 2, mt: 'auto' }}
                        >
                          Message
                        </Button>

                        <Typography variant="caption" color="text.secondary" sx={{ mt: 1 }}>
                          Requested {moment(booking.createdAt).fromNow()}
                        </Typography>
                      </Box>
                    </Grid>
                  </Grid>

                  {/* Special Requests */}
                  {booking.specialRequests && (
                    <Box sx={{ mt: 2, p: 2, bgcolor: 'grey.50', borderRadius: 2 }}>
                      <Typography variant="subtitle2" fontWeight={600} gutterBottom>
                        Special Requests:
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        {booking.specialRequests}
                      </Typography>
                    </Box>
                  )}
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      )}
    </Box>
  );
};

export default MyBookings;