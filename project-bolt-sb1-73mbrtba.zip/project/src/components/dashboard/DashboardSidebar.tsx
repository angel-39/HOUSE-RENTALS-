import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  Paper,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Typography,
  Box,
  Avatar,
  Divider
} from '@mui/material';
import {
  Home,
  Building,
  Calendar,
  User,
  Settings,
  BarChart3
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

const DashboardSidebar: React.FC = () => {
  const { user } = useAuth();
  const location = useLocation();

  const menuItems = [
    { path: '/dashboard', label: 'Overview', icon: <BarChart3 size={20} /> },
    ...(user?.role === 'owner' 
      ? [{ path: '/dashboard/properties', label: 'My Properties', icon: <Building size={20} /> }]
      : []
    ),
    { path: '/dashboard/bookings', label: 'My Bookings', icon: <Calendar size={20} /> },
    { path: '/dashboard/profile', label: 'Profile', icon: <User size={20} /> },
  ];

  const isActive = (path: string) => {
    if (path === '/dashboard') {
      return location.pathname === '/dashboard';
    }
    return location.pathname.startsWith(path);
  };

  return (
    <Paper
      sx={{
        p: 0,
        borderRadius: 3,
        boxShadow: '0 4px 20px rgba(0,0,0,0.08)',
        position: 'sticky',
        top: 20
      }}
    >
      {/* User Profile Section */}
      <Box sx={{ p: 3, textAlign: 'center' }}>
        <Avatar
          sx={{
            width: 60,
            height: 60,
            bgcolor: 'primary.main',
            mx: 'auto',
            mb: 2,
            fontSize: '1.5rem'
          }}
        >
          {user?.name.charAt(0).toUpperCase()}
        </Avatar>
        <Typography variant="h6" fontWeight={600}>
          {user?.name}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          {user?.role === 'owner' ? 'Property Owner' : 'Renter'}
        </Typography>
      </Box>

      <Divider />

      {/* Navigation Menu */}
      <List sx={{ p: 1 }}>
        {menuItems.map((item) => (
          <ListItem
            key={item.path}
            component={Link}
            to={item.path}
            sx={{
              borderRadius: 2,
              mb: 0.5,
              mx: 1,
              textDecoration: 'none',
              color: 'inherit',
              bgcolor: isActive(item.path) ? 'primary.light' : 'transparent',
              color: isActive(item.path) ? 'white' : 'text.primary',
              '&:hover': {
                bgcolor: isActive(item.path) ? 'primary.main' : 'grey.100'
              }
            }}
          >
            <ListItemIcon
              sx={{
                color: isActive(item.path) ? 'white' : 'text.secondary',
                minWidth: 40
              }}
            >
              {item.icon}
            </ListItemIcon>
            <ListItemText
              primary={item.label}
              primaryTypographyProps={{
                fontWeight: isActive(item.path) ? 600 : 400
              }}
            />
          </ListItem>
        ))}
      </List>
    </Paper>
  );
};

export default DashboardSidebar;