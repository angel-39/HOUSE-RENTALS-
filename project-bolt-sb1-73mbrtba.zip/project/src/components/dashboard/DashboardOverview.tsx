import React, { useState, useEffect } from 'react';
import {
  Grid,
  Card,
  CardContent,
  Typography,
  Box,
  LinearProgress,
  Alert
} from '@mui/material';
import {
  Building,
  Calendar,
  DollarSign,
  TrendingUp,
  Users,
  CheckCircle
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import axios from 'axios';

interface DashboardStats {
  totalProperties?: number;
  availableProperties?: number;
  totalBookings: number;
  activeBookings: number;
  pendingBookings: number;
  totalRevenue?: number;
  monthlyRevenue?: number;
}

const DashboardOverview: React.FC = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState<DashboardStats>({
    totalBookings: 0,
    activeBookings: 0,
    pendingBookings: 0
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchDashboardStats();
  }, []);

  const fetchDashboardStats = async () => {
    try {
      setLoading(true);
      
      // Fetch bookings
      const bookingsResponse = await axios.get('/bookings');
      const bookings = bookingsResponse.data.bookings || [];
      
      const bookingStats = {
        totalBookings: bookings.length,
        activeBookings: bookings.filter((b: any) => b.status === 'active').length,
        pendingBookings: bookings.filter((b: any) => b.status === 'pending').length
      };

      // If user is owner, fetch property stats
      if (user?.role === 'owner') {
        const propertiesResponse = await axios.get('/properties/owner/my-properties');
        const properties = propertiesResponse.data.properties || [];
        
        const propertyStats = {
          totalProperties: properties.length,
          availableProperties: properties.filter((p: any) => p.availability.isAvailable).length,
          totalRevenue: bookings
            .filter((b: any) => b.status === 'active' || b.status === 'completed')
            .reduce((sum: number, b: any) => sum + b.monthlyRent, 0),
          monthlyRevenue: bookings
            .filter((b: any) => b.status === 'active')
            .reduce((sum: number, b: any) => sum + b.monthlyRent, 0)
        };
        
        setStats({ ...bookingStats, ...propertyStats });
      } else {
        setStats(bookingStats);
      }
    } catch (error: any) {
      setError('Failed to load dashboard statistics');
      console.error('Dashboard stats error:', error);
    } finally {
      setLoading(false);
    }
  };

  const StatCard: React.FC<{
    title: string;
    value: string | number;
    icon: React.ReactNode;
    color: string;
    subtitle?: string;
  }> = ({ title, value, icon, color, subtitle }) => (
    <Card
      sx={{
        height: '100%',
        transition: 'all 0.3s ease',
        '&:hover': {
          transform: 'translateY(-4px)',
          boxShadow: '0 8px 30px rgba(0,0,0,0.12)'
        }
      }}
    >
      <CardContent>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Box>
            <Typography variant="h4" fontWeight={700} color={color}>
              {loading ? <LinearProgress sx={{ width: 60 }} /> : value}
            </Typography>
            <Typography variant="h6" color="text.secondary" gutterBottom>
              {title}
            </Typography>
            {subtitle && (
              <Typography variant="body2" color="text.secondary">
                {subtitle}
              </Typography>
            )}
          </Box>
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              width: 60,
              height: 60,
              borderRadius: '50%',
              bgcolor: `${color}15`,
              color: color
            }}
          >
            {icon}
          </Box>
        </Box>
      </CardContent>
    </Card>
  );

  if (error) {
    return (
      <Alert severity="error" sx={{ borderRadius: 2 }}>
        {error}
      </Alert>
    );
  }

  return (
    <Box>
      {/* Header */}
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" fontWeight={700} gutterBottom>
          Welcome back, {user?.name}!
        </Typography>
        <Typography variant="h6" color="text.secondary">
          Here's what's happening with your {user?.role === 'owner' ? 'properties' : 'bookings'} today.
        </Typography>
      </Box>

      {/* Stats Grid */}
      <Grid container spacing={3}>
        {user?.role === 'owner' ? (
          <>
            <Grid item xs={12} sm={6} md={3}>
              <StatCard
                title="Total Properties"
                value={stats.totalProperties || 0}
                icon={<Building size={24} />}
                color="#1976d2"
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <StatCard
                title="Available Properties"
                value={stats.availableProperties || 0}
                icon={<CheckCircle size={24} />}
                color="#4caf50"
                subtitle={`${stats.totalProperties ? Math.round(((stats.availableProperties || 0) / stats.totalProperties) * 100) : 0}% of total`}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <StatCard
                title="Monthly Revenue"
                value={`$${(stats.monthlyRevenue || 0).toLocaleString()}`}
                icon={<DollarSign size={24} />}
                color="#ff9800"
                subtitle="Active bookings"
              />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <StatCard
                title="Total Bookings"
                value={stats.totalBookings}
                icon={<Calendar size={24} />}
                color="#9c27b0"
                subtitle={`${stats.pendingBookings} pending`}
              />
            </Grid>
          </>
        ) : (
          <>
            <Grid item xs={12} sm={6} md={4}>
              <StatCard
                title="Total Bookings"
                value={stats.totalBookings}
                icon={<Calendar size={24} />}
                color="#1976d2"
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <StatCard
                title="Active Bookings"
                value={stats.activeBookings}
                icon={<CheckCircle size={24} />}
                color="#4caf50"
                subtitle="Currently renting"
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <StatCard
                title="Pending Requests"
                value={stats.pendingBookings}
                icon={<TrendingUp size={24} />}
                color="#ff9800"
                subtitle="Awaiting approval"
              />
            </Grid>
          </>
        )}
      </Grid>

      {/* Quick Actions */}
      <Card sx={{ mt: 4, p: 3 }}>
        <Typography variant="h6" fontWeight={600} gutterBottom>
          Quick Actions
        </Typography>
        <Grid container spacing={2}>
          {user?.role === 'owner' ? (
            <>
              <Grid item xs={12} sm={6} md={3}>
                <Box
                  sx={{
                    p: 2,
                    border: '2px dashed #e0e0e0',
                    borderRadius: 2,
                    textAlign: 'center',
                    cursor: 'pointer',
                    '&:hover': { borderColor: 'primary.main', bgcolor: 'primary.light', color: 'white' }
                  }}
                >
                  <Building size={24} />
                  <Typography variant="body2" sx={{ mt: 1 }}>
                    Add New Property
                  </Typography>
                </Box>
              </Grid>
              <Grid item xs={12} sm={6} md={3}>
                <Box
                  sx={{
                    p: 2,
                    border: '2px dashed #e0e0e0',
                    borderRadius: 2,
                    textAlign: 'center',
                    cursor: 'pointer',
                    '&:hover': { borderColor: 'primary.main', bgcolor: 'primary.light', color: 'white' }
                  }}
                >
                  <Users size={24} />
                  <Typography variant="body2" sx={{ mt: 1 }}>
                    Manage Tenants
                  </Typography>
                </Box>
              </Grid>
            </>
          ) : (
            <>
              <Grid item xs={12} sm={6} md={3}>
                <Box
                  sx={{
                    p: 2,
                    border: '2px dashed #e0e0e0',
                    borderRadius: 2,
                    textAlign: 'center',
                    cursor: 'pointer',
                    '&:hover': { borderColor: 'primary.main', bgcolor: 'primary.light', color: 'white' }
                  }}
                >
                  <Building size={24} />
                  <Typography variant="body2" sx={{ mt: 1 }}>
                    Browse Properties
                  </Typography>
                </Box>
              </Grid>
              <Grid item xs={12} sm={6} md={3}>
                <Box
                  sx={{
                    p: 2,
                    border: '2px dashed #e0e0e0',
                    borderRadius: 2,
                    textAlign: 'center',
                    cursor: 'pointer',
                    '&:hover': { borderColor: 'primary.main', bgcolor: 'primary.light', color: 'white' }
                  }}
                >
                  <Calendar size={24} />
                  <Typography variant="body2" sx={{ mt: 1 }}>
                    View Bookings
                  </Typography>
                </Box>
              </Grid>
            </>
          )}
        </Grid>
      </Card>
    </Box>
  );
};

export default DashboardOverview;