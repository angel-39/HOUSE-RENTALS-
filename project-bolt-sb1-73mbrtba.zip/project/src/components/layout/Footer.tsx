import React from 'react';
import { Box, Container, Grid, Typography, Link, IconButton } from '@mui/material';
import { Home, Mail, Phone, MapPin, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <Box
      component="footer"
      sx={{
        backgroundColor: 'grey.900',
        color: 'white',
        py: 6,
        mt: 'auto'
      }}
    >
      <Container maxWidth="lg">
        <Grid container spacing={4}>
          {/* Company Info */}
          <Grid item xs={12} md={4}>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
              <Home size={32} color="#1976d2" />
              <Typography variant="h5" sx={{ ml: 1, fontWeight: 700 }}>
                RentEase
              </Typography>
            </Box>
            <Typography variant="body2" sx={{ mb: 2, color: 'grey.300' }}>
              Your trusted partner in finding the perfect rental property. 
              We connect property owners with quality renters through our 
              comprehensive platform.
            </Typography>
            <Box sx={{ display: 'flex', gap: 1 }}>
              <IconButton sx={{ color: 'primary.main' }}>
                <Facebook size={20} />
              </IconButton>
              <IconButton sx={{ color: 'primary.main' }}>
                <Twitter size={20} />
              </IconButton>
              <IconButton sx={{ color: 'primary.main' }}>
                <Instagram size={20} />
              </IconButton>
              <IconButton sx={{ color: 'primary.main' }}>
                <Linkedin size={20} />
              </IconButton>
            </Box>
          </Grid>

          {/* Quick Links */}
          <Grid item xs={12} sm={6} md={2}>
            <Typography variant="h6" sx={{ mb: 2, fontWeight: 600 }}>
              Quick Links
            </Typography>
            {['Home', 'Properties', 'About Us', 'Contact', 'FAQ'].map((item) => (
              <Link
                key={item}
                href="#"
                sx={{
                  display: 'block',
                  color: 'grey.300',
                  textDecoration: 'none',
                  mb: 1,
                  '&:hover': { color: 'primary.main' }
                }}
              >
                {item}
              </Link>
            ))}
          </Grid>

          {/* Services */}
          <Grid item xs={12} sm={6} md={2}>
            <Typography variant="h6" sx={{ mb: 2, fontWeight: 600 }}>
              Services
            </Typography>
            {['Property Management', 'Rental Listings', 'Tenant Screening', 'Maintenance', 'Legal Support'].map((item) => (
              <Link
                key={item}
                href="#"
                sx={{
                  display: 'block',
                  color: 'grey.300',
                  textDecoration: 'none',
                  mb: 1,
                  '&:hover': { color: 'primary.main' }
                }}
              >
                {item}
              </Link>
            ))}
          </Grid>

          {/* Contact Info */}
          <Grid item xs={12} md={4}>
            <Typography variant="h6" sx={{ mb: 2, fontWeight: 600 }}>
              Contact Us
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
              <MapPin size={18} color="#00acc1" />
              <Typography variant="body2" sx={{ ml: 1, color: 'grey.300' }}>
                123 Business Ave, Suite 100<br />
                New York, NY 10001
              </Typography>
            </Box>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
              <Phone size={18} color="#00acc1" />
              <Typography variant="body2" sx={{ ml: 1, color: 'grey.300' }}>
                (555) 123-4567
              </Typography>
            </Box>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
              <Mail size={18} color="#00acc1" />
              <Typography variant="body2" sx={{ ml: 1, color: 'grey.300' }}>
                support@rentease.com
              </Typography>
            </Box>
          </Grid>
        </Grid>

        {/* Bottom Bar */}
        <Box
          sx={{
            borderTop: '1px solid #333',
            mt: 4,
            pt: 3,
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: 2
          }}
        >
          <Typography variant="body2" color="grey.400">
            © 2025 RentEase. All rights reserved.
          </Typography>
          <Box sx={{ display: 'flex', gap: 3 }}>
            <Link href="#" sx={{ color: 'grey.400', textDecoration: 'none', '&:hover': { color: 'primary.main' } }}>
              Privacy Policy
            </Link>
            <Link href="#" sx={{ color: 'grey.400', textDecoration: 'none', '&:hover': { color: 'primary.main' } }}>
              Terms of Service
            </Link>
            <Link href="#" sx={{ color: 'grey.400', textDecoration: 'none', '&:hover': { color: 'primary.main' } }}>
              Cookie Policy
            </Link>
          </Box>
        </Box>
      </Container>
    </Box>
  );
};

export default Footer;